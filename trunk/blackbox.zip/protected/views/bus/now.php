<?php
	echo "$bus->cLat|$bus->cLong";
?>